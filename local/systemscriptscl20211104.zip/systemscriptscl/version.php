<?php

defined('MOODLE_INTERNAL') || die;
$plugin->requires   = 2020011106;                       // This plugin requires Moodle VER 3.0.
$plugin->version    = 2020011106;                       // This plugins version number.
$plugin->release    = 'v1.0';                           // This plugins release number.
$plugin->maturity   = MATURITY_STABLE;
$plugin->component  = 'local_systemscriptscl';